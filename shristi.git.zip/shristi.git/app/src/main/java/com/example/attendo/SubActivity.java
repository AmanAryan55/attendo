package com.example.attendo;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.attendo.Database.DataSource;
import com.example.attendo.Database.MyDB;
import com.example.attendo.Model.SubAdapter;
import com.example.attendo.Model.SubEntity;
import com.example.attendo.Util.SampleData;

import java.util.List;

public class SubActivity extends AppCompatActivity {

    private RecyclerView mRView;
    private List<SubEntity> mSubList;
    private DataSource mDataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mDataSource = new DataSource(this);
        mDataSource.open();

        mRView=(RecyclerView)findViewById(R.id.recyclerView);

        FloatingActionButton fab = findViewById(R.id.addSub);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initRView();

        mSubList= SampleData.getSampleData();
        showData();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mDataSource.open();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        mDataSource.close();
    }

    private void showData()
    {
        SubAdapter subAdapter=new SubAdapter(this,mSubList);
        mRView.setAdapter(subAdapter);
    }

    private void openDialog()
    {
        Dialog mDialog=new Dialog();
        mDialog.show(getSupportFragmentManager(),"TAG");
    }

    private void initRView()
    {
        mRView.hasFixedSize();
        LinearLayoutManager layoutManager= new LinearLayoutManager(this);
        mRView.setLayoutManager(layoutManager);
    }

}
