package com.example.attendo.Model;

import android.content.ContentValues;

import com.example.attendo.Database.Data;

import java.util.UUID;

public class SubEntity {

    private String ID;
    private String subname;
    public int present;
    public int absent;

    public SubEntity() {
    }

    public SubEntity(String ID, String subname, int present, int absent) {

        if(ID==null)
        {
            ID= UUID.randomUUID().toString();
        }

        this.ID=ID;
        this.subname = subname;
        this.present = present;
        this.absent = absent;
    }


    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }
    public String getSubname() {
        return subname;
    }

    public void setSubname(String subname) {
        this.subname = subname;
    }

    public int getPresent() {
        return present;
    }

    public void setPresent(int present) {
        this.present = present;
    }

    public int getAbsent() {
        return absent;
    }

    public void setAbsent(int absent) {
        this.absent = absent;
    }

    public ContentValues getValues()
    {
        ContentValues values = new ContentValues(4);
        values.put(Data.Coln_1,this.ID);
        values.put(Data.Coln_2,this.subname);
        values.put(Data.Coln_3,this.present);
        values.put(Data.Coln_4,this.absent);

        return values;
    }

    @Override
    public String toString() {
        return "SubDataItem{" + "ID='" + ID + '\'' +
                            ", Subname='"+ subname + '\'' +
                            ", Present='"+ present +
                            ", Absent='"+ absent + '}';
    }
}
